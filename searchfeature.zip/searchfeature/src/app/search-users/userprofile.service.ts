import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '../../../node_modules/@angular/common/http';
import { UserProfile } from './userprofile';
import { Observable } from '../../../node_modules/rxjs';


const httpOptions ={
  headers :new HttpHeaders({'Content-Type':'application/json'})
};

@Injectable({
  providedIn: 'root'
})
export class UserprofileService {

  private _userUrl='http://localhost:8084/search';
  private _getUserNames='http://localhost:8084/search/unames';
  _Url:string='http://localhost:8084/search';

  private search:string='unames';


  constructor(private http: HttpClient) { }

  getUsers():Observable<UserProfile[]>{
    return  this.http.get<UserProfile[]>(this._getUserNames)
    
   
}

  getUsersByName(userName: string): Observable<any> {

    this._userUrl=this._Url+'/'+this.search+'/'+userName;
    return  this.http.get<UserProfile[]>(this._userUrl)
    }
    //return this.http.get(`${this.baseUrl}/names/${groupName}`);
  //}
}


